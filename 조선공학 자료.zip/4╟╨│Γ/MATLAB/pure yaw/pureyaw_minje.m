clc
clear all
close all

rho = 1000;
L = 3.147;
T = 0.112;
g = 9.81;
Fn = 0.2;
U = Fn*sqrt(g*L);
Fnon = 1/2*rho*L*T*U.^2;
Mnon = 1/2*rho*L^2*T*U.^2;
clear g Fn

%% f1
load PY_Fr02_3_w01293
% plot(PY_Fr02_3_w01293(:,1), PY_Fr02_3_w01293(:,2));

T(1,1) = PY_Fr02_3_w01293(7053) - PY_Fr02_3_w01293(4640);
w(1,1) = 2*pi./T(1,1);
temp1  = 4640;
temp2  = 7053;

Fr02.f(1).t   = PY_Fr02_3_w01293(temp1:temp2, 1);
Fr02.f(1).y   = PY_Fr02_3_w01293(temp1:temp2, 2)/1000;
Fr02.f(1).psi = PY_Fr02_3_w01293(temp1:temp2, 3)*pi./180;
Fr02.f(1).X   = PY_Fr02_3_w01293(temp1:temp2, 4)/Fnon;
Fr02.f(1).Y   = PY_Fr02_3_w01293(temp1:temp2, 5)/Fnon;
Fr02.f(1).N   = PY_Fr02_3_w01293(temp1:temp2, 9)/Mnon;

clear temp1 temp2

P = [sin(w(1,1)*Fr02.f(1).t), cos(w(1,1)*Fr02.f(1).t), ones(length(Fr02.f(1).t),1)];
Q = Fr02.f(1).psi;
temp = inv(P'*P)*P'*Q;
Fr02.pha.y(1) = atan2(temp(2), temp(1));
Fr02.amp.y(1) = sqrt(temp(2)^2 + temp(1)^2);
clear P Q temp

Fr02.f(1).r  = + Fr02.amp.y(1) *w(1,1) * cos(w(1,1)*Fr02.f(1).t + Fr02.pha.y(1)) /(U/L);
Fr02.f(1).rd = - Fr02.amp.y(1) *w(1,1)^2 * sin(w(1,1)*Fr02.f(1).t + Fr02.pha.y(1)) /(U^2/L^2);

Fr02.amp_r(1)  = max(Fr02.f(1).r);
Fr02.amp_rd(1) = max(Fr02.f(1).rd);

clear PY_Fr02_3_w01293

%% f2
load PY_Fr02_4_5_w01940
% plot(PY_Fr02_4_5_w01940(:,1), PY_Fr02_4_5_w01940(:,2));

T(2,1) = PY_Fr02_4_5_w01940(5287) - PY_Fr02_4_5_w01940(3675);
w(2,1) = 2*pi./T(2,1);
temp1  = 3675;
temp2  = 5287;

Fr02.f(2).t   = PY_Fr02_4_5_w01940(temp1:temp2, 1);
Fr02.f(2).y   = PY_Fr02_4_5_w01940(temp1:temp2, 2)/1000;
Fr02.f(2).psi = PY_Fr02_4_5_w01940(temp1:temp2, 3)*pi./180;
Fr02.f(2).X   = PY_Fr02_4_5_w01940(temp1:temp2, 4)/Fnon;
Fr02.f(2).Y   = PY_Fr02_4_5_w01940(temp1:temp2, 5)/Fnon;
Fr02.f(2).N   = PY_Fr02_4_5_w01940(temp1:temp2, 9)/Mnon;

clear temp1 temp2

P = [sin(w(2,1)*Fr02.f(2).t), cos(w(2,1)*Fr02.f(2).t), ones(length(Fr02.f(2).t),1)];
Q = Fr02.f(2).psi;
temp = inv(P'*P)*P'*Q;
Fr02.pha.y(2) = atan2(temp(2), temp(1));
Fr02.amp.y(2) = sqrt(temp(2)^2 + temp(1)^2);
clear P Q temp

Fr02.f(2).r  = + Fr02.amp.y(2) *w(2,1) * cos(w(2,1)*Fr02.f(2).t + Fr02.pha.y(2)) /(U/L);
Fr02.f(2).rd = - Fr02.amp.y(2) *w(2,1)^2 * sin(w(2,1)*Fr02.f(2).t + Fr02.pha.y(2)) /(U^2/L^2);

Fr02.amp_r(2)  = max(Fr02.f(2).r);
Fr02.amp_rd(2) = max(Fr02.f(2).rd);

clear PY_Fr02_4_5_w01940

%% f3
load PY_Fr02_6_w02586
% plot(PY_Fr02_6_w02586(:,1), PY_Fr02_6_w02586(:,2));

T(3,1) = (PY_Fr02_6_w02586(5475) - PY_Fr02_6_w02586(1848))*(1/3);
w(3,1) = 2*pi./T(3,1);
temp1  = 1848;
temp2  = 5475;

Fr02.f(3).t   = PY_Fr02_6_w02586(temp1:temp2, 1);
Fr02.f(3).y   = PY_Fr02_6_w02586(temp1:temp2, 2)/1000;
Fr02.f(3).psi = PY_Fr02_6_w02586(temp1:temp2, 3)*pi./180;
Fr02.f(3).X   = PY_Fr02_6_w02586(temp1:temp2, 4)/Fnon;
Fr02.f(3).Y   = PY_Fr02_6_w02586(temp1:temp2, 5)/Fnon;
Fr02.f(3).N   = PY_Fr02_6_w02586(temp1:temp2, 9)/Mnon;

clear temp1 temp2

P = [sin(w(3,1)*Fr02.f(3).t), cos(w(3,1)*Fr02.f(3).t), ones(length(Fr02.f(3).t),1)];
Q = Fr02.f(3).psi;
temp = inv(P'*P)*P'*Q;
Fr02.pha.y(3) = atan2(temp(2), temp(1));
Fr02.amp.y(3) = sqrt(temp(2)^2 + temp(1)^2);
clear P Q temp

Fr02.f(3).r  = + Fr02.amp.y(3) *w(3,1) * cos(w(3,1)*Fr02.f(3).t + Fr02.pha.y(3))/(U/L);
Fr02.f(3).rd = - Fr02.amp.y(3) *w(3,1)^2  * sin(w(3,1)*Fr02.f(3).t + Fr02.pha.y(3))/(U^2/L^2);

Fr02.amp_r(3)  = max(Fr02.f(3).r);
Fr02.amp_rd(3) = max(Fr02.f(3).rd);

clear PY_Fr02_6_w02586

%% f4
load PY_Fr02_7_5_w03233
% plot(PY_Fr02_7_5_w03233(:,1), PY_Fr02_7_5_w03233(:,2));

T(4,1) = (PY_Fr02_7_5_w03233(5828) - PY_Fr02_7_5_w03233(2927))*(1/3);
w(4,1) = 2*pi./T(4,1);
temp1  = 2927;
temp2  = 5828;

Fr02.f(4).t   = PY_Fr02_7_5_w03233(temp1:temp2, 1);
Fr02.f(4).y   = PY_Fr02_7_5_w03233(temp1:temp2, 2)/1000;
Fr02.f(4).psi = PY_Fr02_7_5_w03233(temp1:temp2, 3)*pi./180;
Fr02.f(4).X   = PY_Fr02_7_5_w03233(temp1:temp2, 4)/Fnon;
Fr02.f(4).Y   = PY_Fr02_7_5_w03233(temp1:temp2, 5)/Fnon;
Fr02.f(4).N   = PY_Fr02_7_5_w03233(temp1:temp2, 9)/Mnon;

clear temp1 temp2

P = [sin(w(4,1)*Fr02.f(4).t), cos(w(4,1)*Fr02.f(4).t), ones(length(Fr02.f(4).t),1)];
Q = Fr02.f(4).psi;
temp = inv(P'*P)*P'*Q;
Fr02.pha.y(4) = atan2(temp(2), temp(1));
Fr02.amp.y(4) = sqrt(temp(2)^2 + temp(1)^2);
clear P Q temp

Fr02.f(4).r  = + Fr02.amp.y(4) *w(4,1) * cos(w(4,1)*Fr02.f(4).t + Fr02.pha.y(4)) /(U/L);
Fr02.f(4).rd = - Fr02.amp.y(4) *w(4,1)^2 * sin(w(4,1)*Fr02.f(4).t + Fr02.pha.y(4)) /(U^2/L^2);

Fr02.amp_r(4)  = max(Fr02.f(4).r);
Fr02.amp_rd(4) = max(Fr02.f(4).rd);

clear PY_Fr02_7_5_w03233

%% f5
load PY_Fr02_9_w03879
% plot(PY_Fr02_9_w03879(:,1), PY_Fr02_9_w03879(:,2));

T(5,1) = (PY_Fr02_9_w03879(4883) - PY_Fr02_9_w03879(2464))*(1/3);
w(5,1) = 2*pi./T(5,1);
temp1  = 2464;
temp2  = 4883;

Fr02.f(5).t   = PY_Fr02_9_w03879(temp1:temp2, 1);
Fr02.f(5).y   = PY_Fr02_9_w03879(temp1:temp2, 2)/1000;
Fr02.f(5).psi = PY_Fr02_9_w03879(temp1:temp2, 3)*pi./180;
Fr02.f(5).X   = PY_Fr02_9_w03879(temp1:temp2, 4)/Fnon;
Fr02.f(5).Y   = PY_Fr02_9_w03879(temp1:temp2, 5)/Fnon;
Fr02.f(5).N   = PY_Fr02_9_w03879(temp1:temp2, 9)/Mnon;

clear temp1 temp2

P = [sin(w(5,1)*Fr02.f(5).t), cos(w(5,1)*Fr02.f(5).t), ones(length(Fr02.f(5).t),1)];
Q = Fr02.f(5).psi;
temp = inv(P'*P)*P'*Q;
Fr02.pha.y(5) = atan2(temp(2), temp(1));
Fr02.amp.y(5) = sqrt(temp(2)^2 + temp(1)^2);
clear P Q temp

Fr02.f(5).r  = + Fr02.amp.y(5) *w(5,1) * cos(w(5,1)*Fr02.f(5).t + Fr02.pha.y(5)) /(U/L);
Fr02.f(5).rd = - Fr02.amp.y(5) *w(5,1)^2 * sin(w(5,1)*Fr02.f(5).t + Fr02.pha.y(5)) /(U^2/L^2);

Fr02.amp_r(5)  = max(Fr02.f(5).r);
Fr02.amp_rd(5) = max(Fr02.f(5).rd);

clear PY_Fr02_9_w03879

%% f6
load PY_Fr02_12_w05172
% plot(PY_Fr02_12_w05172(:,1), PY_Fr02_12_w05172(:,2));

T(6,1) = (PY_Fr02_12_w05172(4577) - PY_Fr02_12_w05172(2765))*(1/3);
w(6,1) = 2*pi./T(6,1);
temp1  = 2765;
temp2  = 4577;

Fr02.f(6).t   = PY_Fr02_12_w05172(temp1:temp2, 1);
Fr02.f(6).y   = PY_Fr02_12_w05172(temp1:temp2, 2)/1000;
Fr02.f(6).psi = PY_Fr02_12_w05172(temp1:temp2, 3)*pi./180;
Fr02.f(6).X   = PY_Fr02_12_w05172(temp1:temp2, 4)/Fnon;
Fr02.f(6).Y   = PY_Fr02_12_w05172(temp1:temp2, 5)/Fnon;
Fr02.f(6).N   = PY_Fr02_12_w05172(temp1:temp2, 9)/Mnon;

clear temp1 temp2

P = [sin(w(6,1)*Fr02.f(6).t), cos(w(6,1)*Fr02.f(6).t), ones(length(Fr02.f(6).t),1)];
Q = Fr02.f(6).psi;
temp = inv(P'*P)*P'*Q;
Fr02.pha.y(6) = atan2(temp(2), temp(1));
Fr02.amp.y(6) = sqrt(temp(2)^2 + temp(1)^2);
clear P Q temp

Fr02.f(6).r  = + Fr02.amp.y(6) *w(6,1) * cos(w(6,1)*Fr02.f(6).t + Fr02.pha.y(6)) /(U/L);
Fr02.f(6).rd = - Fr02.amp.y(6) *w(6,1)^2 * sin(w(6,1)*Fr02.f(6).t + Fr02.pha.y(6)) /(U^2/L^2);

Fr02.amp_r(6)  = max(Fr02.f(6).r);
Fr02.amp_rd(6) = max(Fr02.f(6).rd);

clear PY_Fr02_12_w05172

%% f7
load PY_Fr02_15_w06465
% plot(PY_Fr02_15_w06465(:,1), PY_Fr02_15_w06465(:,2));

T(7,1) = (PY_Fr02_15_w06465(5173) - PY_Fr02_15_w06465(2761))*(1/5);
w(7,1) = 2*pi./T(7,1);
temp1  = 2761;
temp2  = 5173;

Fr02.f(7).t   = PY_Fr02_15_w06465(temp1:temp2, 1);
Fr02.f(7).y   = PY_Fr02_15_w06465(temp1:temp2, 2)/1000;
Fr02.f(7).psi = PY_Fr02_15_w06465(temp1:temp2, 3)*pi./180;
Fr02.f(7).X   = PY_Fr02_15_w06465(temp1:temp2, 4)/Fnon;
Fr02.f(7).Y   = PY_Fr02_15_w06465(temp1:temp2, 5)/Fnon;
Fr02.f(7).N   = PY_Fr02_15_w06465(temp1:temp2, 9)/Mnon;

clear temp1 temp2

P = [sin(w(7,1)*Fr02.f(7).t), cos(w(7,1)*Fr02.f(7).t), ones(length(Fr02.f(7).t),1)];
Q = Fr02.f(7).psi;
temp = inv(P'*P)*P'*Q;
Fr02.pha.y(7) = atan2(temp(2), temp(1));
Fr02.amp.y(7) = sqrt(temp(2)^2 + temp(1)^2);
clear P Q temp

Fr02.f(7).r  = + Fr02.amp.y(7) *w(7,1) * cos(w(7,1)*Fr02.f(7).t + Fr02.pha.y(7)) /(U/L);
Fr02.f(7).rd = - Fr02.amp.y(7) *w(7,1)^2 * sin(w(7,1)*Fr02.f(7).t + Fr02.pha.y(7)) /(U^2/L^2);

Fr02.amp_r(7)  = max(Fr02.f(7).r);
Fr02.amp_rd(7) = max(Fr02.f(7).rd);

clear PY_Fr02_15_w06465

%% Fr 0.1, 0.2
% Y N [1 rd r r.^3]
for i =1:length(w)
    P = [ones(length(Fr02.f(i).r),1), Fr02.f(i).rd, Fr02.f(i).r, Fr02.f(i).r.^3];
    Q = [Fr02.f(i).Y, Fr02.f(i).N];
    temp = inv(P'*P)*P'*Q;
    Y0(i,1) = temp(1,1); Yrd(i,1) = temp(2,1); Yr(i,1) = temp(3,1); Yrrr(i,1) = temp(4,1);
    N0(i,1) = temp(1,2); Nrd(i,1) = temp(2,2); Nr(i,1) = temp(3,2); Nrrr(i,1) = temp(4,2);
    clear P Q temp
    
% X [1 r.^2]
    P = [ones(length(Fr02.f(i).r), 1), Fr02.f(i).r.^2];
    Q = [Fr02.f(i).X];
    temp = inv(P'*P)*P'*Q;
    X0(i,1) = temp(1,1); Xrr(i,1) = temp(2,1);
    clear P Q temp
end

%% Regression
% Velocity
A = [Fr02.amp_r'];
B = [Fr02.amp_r'].^2;
C = [Fr02.amp_r'].^3;

Vel.X = Xrr.*B;
Vel.Y = Yr.*A + Yrrr.*C;
Vel.N = Nr.*A + Nrrr.*C;

Q = [Vel.X];
P = [B];
R = inv(P'*P)*P'*Q;
D.Xrr = R(1,1);
clear Q P R

Q = [Vel.Y, Vel.N];
P = [A, C];
R = inv(P'*P)*P'*Q;
D.Yr = R(1,1); D.Yrrr(1) = R(2,1);
D.Nr = R(1,2); D.Nrrr(1) = R(2,2);
clear Q P R

r = (0:0.01:0.5)';

Vel.Y1 = D.Yr.*r + D.Yrrr.*r.^3;
Vel.N1 = D.Nr.*r + D.Nrrr.*r.^3;

% Acc
E = [Fr02.amp_rd'];

Acc.Y = Yrd.*E;
Acc.N = Nrd.*E;

Q = [Acc.Y, Acc.N];
P = [E];
R = inv(P'*P)*P'*Q;
D.Yrd = R(1);
D.Nrd = R(2);
clear Q P R

rd = (0:0.01:1)';

Acc.Y1 = D.Yrd.*rd;
Acc.N1 = D.Nrd.*rd;
%% Plot
figure(1)
subplot(121); grid on; hold on;
plot(A, Vel.Y, 'bo');
plot(r, Vel.Y1, '--r');
xlabel('r');
ylabel('Y');
title('Yr');

subplot(122); grid on; hold on;
plot(A, Vel.N, 'bo');
plot(r, Vel.N1, '--r');
xlabel('r');
ylabel('N');
title('Nr');

figure(2)
subplot(121); grid on; hold on;
plot(E, Acc.Y, 'bo');
plot(rd, Acc.Y1, '--r');
xlabel('rdot');
ylabel('Y');
title('Yrd');

subplot(122); grid on; hold on;
plot(E, Acc.N, 'bo');
plot(rd, Acc.N1, '--r');
xlabel('rdot');
ylabel('N');
title('Nrd');
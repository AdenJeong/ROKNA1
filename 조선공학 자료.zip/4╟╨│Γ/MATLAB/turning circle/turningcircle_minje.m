clc
clear all
close all

rho = 1000;

L = 3.147;
T = 0.112;
m = 72.6/(0.5*rho*L^2*T);
U = [0.555, 1.111]';

time_final = 58;
time_step  = 0.01;
time(1) = 0;

j = 2;                                                                     % Fr 0.1 ���� ����!!!!!

u(1)  = U(j); v(1)  = 0;  r(1)   = 0;
ud(1) = 0;    vd(1) = 0;  rd(1)  = 0;
XH(1) = 0;    YH(1) = 0;  NH(1)  = 0;
XR(1) = 0;    YR(1) = 0;  NR(1)  = 0;
x(1)  = 0;     y(1) = 0;  psi(1) = 0;

del(1) = 0;
degVel = 35;                                                               % Ÿ�� �ӵ� 35 [deg/s]


Xuu    = -6.634;
Thrust = +6.634*u(1)^2;

%% resistance test
Xud = -0.01307;                                                            % ���̴�
%% static drift test (Cal_171123)
X0   = [-0.001437691536096]';
Y0   = [-0.001412540863210]';
N0   = [-4.911763604970274e-04]';
Xvv  = [-0.012417591470459]';
Yv   = [-0.399525059560660]';
Yvvv = [-0.935939121770730]';
Nv   = [-0.030634989973877]';
Nvvv = [-0.401254319799983]';
%% static rudder test (Cal_171123)
Xdd  = [-0.095959464039892]';
Yd   = [-0.147806339016167]';  
Yddd = [0.094279337773026]';
Nd   = [0.066709229181041]';
Nddd = [-0.043966563452268]';
%% pure sway test (Cal_171123)
Yvd  = [-0.277119523142365]';
Nvd  = [0.010627082203056]';
%% pure yaw test (Cal_171123)
Xrr  = [0.002136023151703]';
Yr   = [-0.059270099478998]';
Yrrr = [-0.066416867347266]';
Nr   = [-0.071091780651678]';
Nrrr = [-0.046722879557949]';
Yrd  = [-0.027485446101350]';
Nrd  = [-0.008313585150333]';
%%

Yvd = Yvd*(0.5*rho*L^2*T);      
Nvd = Nvd*(0.5*rho*L^3*T);   
Yrd = Yrd*(0.5*rho*L^3*T);      
Nrd = Nrd*(0.5*rho*L^4*T);   

for i = 1:time_final/time_step

    time(i+1) = time_step*i;
    del(i+1)  = del(i) + degVel * time_step * pi/180;     
    
    if abs(del(i+1)) > abs(25 * pi/180),                                   % Ÿ�� 25�� ���� ư��
%                 del(i+1) = 25 * pi/180;
        del(i+1) = sign(del(i))*25 * pi/180;
    end

    Uc = sqrt(u(i).^2 + v(i).^2);

    u_non = u(i)/Uc;
    v_non = v(i)/Uc;
    r_non = r(i)/(Uc/L);
    
    XH(i+1) = X0 + Xvv*v_non^2 + Xrr*r_non^2 + m*v_non*r_non;    
    YH(i+1) = Y0 + Yv*v_non + Yvvv*v_non^3 + Yr*r_non + Yrrr*r_non^3;
    NH(i+1) = N0 + Nv*v_non + Nvvv*v_non^3 + Nr*r_non + Nrrr*r_non^3;
    
    XR(i+1) = Xdd*del(i+1)^2;
    YR(i+1) = Yd*del(i+1) + Yddd*del(i+1)^3; 
    NR(i+1) = Nd*del(i+1) + Nddd*del(i+1)^3;
    
    R = (Xuu*u(i)^2);

    X = (XH(i+1) + XR(i+1))*(0.5*rho*L*T*Uc^2) + R + Thrust;
    Y = (YH(i+1) + YR(i+1))*(0.5*rho*L*T*Uc^2);
    N = (NH(i+1) + NR(i+1))*(0.5*rho*L^2*T*Uc^2);
    
    
    
    Mass = [m - Xud,       0,       0;
                  0,   - Yvd,    -Yrd;
                  0,   - Nvd,   - Nrd];
              
    Mass(1,1) = Mass(1,1)*(0.5*rho*L^2*T);
              
    acc = inv(Mass)*[X Y N]';
    
    ud(i+1) = acc(1);
    vd(i+1) = acc(2);
    rd(i+1) = acc(3);
    
    u(i+1) = u(i) + time_step*ud(i);
    v(i+1) = v(i) + time_step*vd(i);
    r(i+1) = r(i) + time_step*rd(i);
    
    xdot = cos(psi(i))*u(i+1) - sin(psi(i))*v(i+1);
    ydot = sin(psi(i))*u(i+1) + cos(psi(i))*v(i+1);
    pdot = r(i+1);
    
    x(i+1)   = x(i)   + time_step*xdot;
    y(i+1)   = y(i)   + time_step*ydot;
    psi(i+1) = psi(i) + time_step*pdot;
   
end
a = del /( pi/180);

% Fig10_a ���� ������
% A = [454  517  580  636  674  710  744  768  787  808  823  833  845  852  861  864  865  865  864  860  856  853  848  841  838  830  819  813  804  795  787  782  768  758  752  742  733  720  712  703  694  679  664  652  637  627  612  595  581  569  559  549  542  532  519  507  490  474  471  465  462  451  437  428  421  415  405  394  383  377  367  362  351  346  340  331  323  314  309  306  298  290  283  281  276  270  265  263  259   257  253  251  250  249  247  247  246  248  248  250  251  254  256  257  262  264  270  273  277  281  289  295  300  303  310  316  324  331  339  347  355  365  373  382  394  400  408  420  427  441  452  460  474  490  503  519  527  546  556  568  565  590  605  618  634  644  650  660  669 712];
% B = [734  736  736  726  714  694  675  658  639  618  596  578  557  532  512  488  467  445  418  400  380  367  355  340  330  314  297  289  280  267  257  250  239  230  223  217  208  203  198  194  191  184  177  175  169  167  165  161  161  159  159  159  160  160  160  161  163  168  167  171  171  175  180  183  186  188  196  201  208  211  218  221  228  234  239  248  256  264  270  276  287  299  307  314  323  333  345  352   363  374  388  395  404  416  424  433  443  459  472  481  492  502  512  523  530  540  551  561  567  576  587  594  604  609  617  623  632  640  647  653  660  667  675  679  683  687  692  696  700  706  710  712  716  720  723  725  727  727  726  726  725  725  722  719  713  712  711  708  705  689];
% A = 6/867 * A -3.1349;
% B = -6/790 * B + 5.5759;

% % % Fig11_b ���� ������ 
% A = [971  959  948  937   929  914  903  888  880  865  858  852  842  834  827  813  802  794  781  770  758  744  733  725  717  706  698  682  676  670  665  657  649  641  633  622  611  600  590  575  557  548  540  529  520  511  505  493  477  471  458  444  433  422  411  398  387  378  368  358  343  331  323  314  307  301  298  288  279  268  260  245  235 231  231  228  221  213  211 202  190  184  179  172  165  160  153  146  138  137  135  133  132  132  128  123  122  123  121  120  120  118  118  118  116  116  115  117  111  107];
% B = [415  408  406    404 400  397  398  397  411  412  408  409  405  401  392  390  403  403  410  416  422  428  425  430  429  431  430  426  420  414  409  407  404  404  400  406  409  410  415  414  413  409  406  405  405  407  412  415  422  426  432 442   449  446  443  447  447  445  447  441  432  429  425  421  418  413  412  412  412  416  413 413  420  420  420  423  426  432 437  438  438  436  433  431  431  433  438  440  432  425  416  413  408  399  390  383  373  364  346  328  312  300  291  279  263  236  224  186  112  24];
% A = 6/88*A-6.8182;
% B = -3.7500e-04*B+0.0075;
% 
% data(1,:) = A;
% data(2,:) = B;

%%
figure(1); grid on; hold on; axis equal
plot(y/L,x/L,'b')
load turning_circle_trajectory
plot(data(2,:), data(1,:), 'r');
axis([-0.5, 5.5, -2, 4]);
xlabel('y/L', 'fontSize', 14);
ylabel('x/L', 'fontSize', 14);
legend('MINJE simulation', 'Araki free running test');
title('Intact  Fr 0.2  \delta = 25^o  maneuvring simulation', 'fontSize', 16);  % Cal 171106

figure(2);
subplot(311); grid on; hold on;
plot(time, u, 'b');
load turning_circle_u
plot(data(1,:), data(2,:), 'r');
axis([0, 55, 0, 1.5]);
xlabel('time [s]', 'fontSize', 13);
ylabel('u [m/s]', 'fontSize', 13);
legend('MINJE simulation', 'Araki Free running test');

subplot(312); grid on; hold on;
plot(time, v, 'b');
load turning_circle_v
plot(data(1,:), data(2,:), 'r');
axis([0, 55, -0.3, 0]);
xlabel('time [s]', 'fontSize', 13);
ylabel('v [m/s]', 'fontSize', 13);

subplot(313); grid on; hold on;
plot(time, r, 'b');
load turning_circle_r
plot(data(1,:), data(2,:), 'r');
axis([0, 55, 0, 0.25]);
xlabel('time [s]', 'fontSize', 13);
ylabel('r [1/s]', 'fontSize', 13);

Intact_PC_Fr02_Y = y/L;
Intact_PC_Fr02_X = x/L;
Intact_PC_Fr02_u = u;
Intact_PC_Fr02_v = v;
Intact_PC_Fr02_r = r;
save Intact_PC_Fr02_Y
save Intact_PC_Fr02_X
save Intact_PC_Fr02_u
save Intact_PC_Fr02_v
save Intact_PC_Fr02_r 
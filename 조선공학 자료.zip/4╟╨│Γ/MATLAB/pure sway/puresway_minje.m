clc
clear all
close all
%
rho = 1000;
L = 3.147;
T = 0.112;
g = 9.81;
Fn = 0.2;
U = Fn * sqrt(g*L);
Fnon = 1/2*rho*L*T*U.^2; % 힘의 무차원
Mnon = 1/2*rho*L^2*T*U.^2; % 모멘트의 무차원
clear g Fn

%% f1
load Fr02_beta3_0_f0_0206

% figure(1); grid on;hold on;
% plot (Fr02_beta3_0_f_0206(:,1), Fr02_beta3_0_f_0206(:,2), 'r');

T(1,1) = Fr02_beta3_0_f0_0206(6947) - Fr02_beta3_0_f0_0206(4536);
w(1,1) = 2*pi./T(1,1);
temp1 = 4530;
temp2 = 6947;

Fr02.f(1).t = Fr02_beta3_0_f0_0206(temp1:temp2, 1);
Fr02.f(1).y = Fr02_beta3_0_f0_0206(temp1:temp2, 2)/1000;
Fr02.f(1).X = Fr02_beta3_0_f0_0206(temp1:temp2, 3)/Fnon;
Fr02.f(1).Y = Fr02_beta3_0_f0_0206(temp1:temp2, 4)/Fnon;
Fr02.f(1).N = Fr02_beta3_0_f0_0206(temp1:temp2, 8)/Mnon;

clear temp1 temp2

P = [sin(w(1,1)*Fr02.f(1).t), cos(w(1,1)*Fr02.f(1).t), ones(length(Fr02.f(1).t),1)];
Q = Fr02.f(1).y;
temp = inv(P'*P)*P'*Q;
Fr02.pha.y(1) = atan2(temp(2), temp(1));
Fr02.amp.y(1) = sqrt(temp(2)^2 + temp(1)^2);
clear P Q temp

Fr02.f(1).v  = + Fr02.amp.y(1) * cos(w(1,1)*Fr02.f(1).t + Fr02.pha.y(1))*w(1,1);
Fr02.f(1).vd = - Fr02.amp.y(1) * sin(w(1,1)*Fr02.f(1).t + Fr02.pha.y(1))*w(1,1)^2;
Fr02.f(1).v  = + Fr02.f(1).v /U;
Fr02.f(1).vd = + Fr02.f(1).vd/(U^2/L);

Fr02.amp_v(1)  = max(Fr02.f(1).v);
Fr02.amp_vd(1) = max(Fr02.f(1).vd);
clear Fr02_beta3_0_f0_0206

%% f2
load Fr02_beta4_5_f0_0308
T(2,1) = Fr02_beta4_5_f0_0308(5621) - Fr02_beta4_5_f0_0308(4002);      % Input T = 32.43 s
w(2,1) = 2*pi./T(2,1);                                                 % Input w = 0.1938
temp1 = 4002;
temp2 = 5621;

Fr02.f(2).t = Fr02_beta4_5_f0_0308(temp1:temp2, 1);
Fr02.f(2).y = Fr02_beta4_5_f0_0308(temp1:temp2, 2)/1000;
Fr02.f(2).X = Fr02_beta4_5_f0_0308(temp1:temp2, 3)/Fnon;
Fr02.f(2).Y = Fr02_beta4_5_f0_0308(temp1:temp2, 4)/Fnon;
Fr02.f(2).N = Fr02_beta4_5_f0_0308(temp1:temp2, 8)/Mnon;

clear temp1 temp2

P = [sin(w(2,1)*Fr02.f(2).t), cos(w(2,1)*Fr02.f(2).t), ones(length(Fr02.f(2).t),1)];   % P = [sinwt, coswt, 5000*1 행렬]    총 0000 * 3 행렬
Q = Fr02.f(2).y;                                                                       % 0000*1 행렬 : y를 sin과 cos과 상수의 합으로 표현
temp = inv(P'*P)*P'*Q;                                                                 % P * temp = Q에서 temp를 구한거      총 3 * 1 행렬
Fr02.pha.y(2) = atan2(temp(2), temp(1));                                               % atan2(x,y) = atan(x/y)
Fr02.amp.y(2) = sqrt(temp(2)^2 + temp(1)^2);                                           % 진폭 구한거
clear P Q temp

Fr02.f(2).v  = + Fr02.amp.y(2) * cos(w(2,1)*Fr02.f(2).t + Fr02.pha.y(2))*w(2,1);
Fr02.f(2).vd = - Fr02.amp.y(2) * sin(w(2,1)*Fr02.f(2).t + Fr02.pha.y(2))*w(2,1)^2;
Fr02.f(2).v  = + Fr02.f(2).v /U;
Fr02.f(2).vd = + Fr02.f(2).vd/(U^2/L);

Fr02.amp_v(2)  = max(Fr02.f(2).v);
Fr02.amp_vd(2) = max(Fr02.f(2).vd);
clear Fr02_beta4_5_f0_0308

%% f3
load Fr02_beta6_0_f0_0411
T(3,1) = Fr02_beta6_0_f0_0411(5912) - Fr02_beta6_0_f0_0411(3490);      % Input T = 32.43 s
w(3,1) = 2*pi./T(3,1);                                                 % Input w = 0.1938
temp1 = 3490;
temp2 = 5912;

Fr02.f(3).t = Fr02_beta6_0_f0_0411(temp1:temp2, 1);
Fr02.f(3).y = Fr02_beta6_0_f0_0411(temp1:temp2, 2)/1000;
Fr02.f(3).X = Fr02_beta6_0_f0_0411(temp1:temp2, 3)/Fnon;
Fr02.f(3).Y = Fr02_beta6_0_f0_0411(temp1:temp2, 4)/Fnon;
Fr02.f(3).N = Fr02_beta6_0_f0_0411(temp1:temp2, 8)/Mnon;

clear temp1 temp2

P = [sin(w(3,1)*Fr02.f(3).t), cos(w(3,1)*Fr02.f(3).t), ones(length(Fr02.f(3).t),1)];   % P = [sinwt, coswt, 5000*1 행렬]    총 0000 * 3 행렬
Q = Fr02.f(3).y;                                                                       % 0000*1 행렬 : y를 sin과 cos과 상수의 합으로 표현
temp = inv(P'*P)*P'*Q;                                                                 % P * temp = Q에서 temp를 구한거      총 3 * 1 행렬
Fr02.pha.y(3) = atan2(temp(2), temp(1));                                               % atan2(x,y) = atan(x/y)
Fr02.amp.y(3) = sqrt(temp(2)^2 + temp(1)^2);                                           % 진폭 구한거
clear P Q temp

Fr02.f(3).v  = + Fr02.amp.y(3) * cos(w(3,1)*Fr02.f(3).t + Fr02.pha.y(3))*w(3,1);
Fr02.f(3).vd = - Fr02.amp.y(3) * sin(w(3,1)*Fr02.f(3).t + Fr02.pha.y(3))*w(3,1)^2;
Fr02.f(3).v  = + Fr02.f(3).v /U;
Fr02.f(3).vd = + Fr02.f(3).vd/(U^2/L);

Fr02.amp_v(3)  = max(Fr02.f(3).v);
Fr02.amp_vd(3) = max(Fr02.f(3).vd);
clear Fr02_beta6_0_f0_0411

%% f4
load Fr02_beta7_5_f0_0513
T(4,1) = Fr02_beta7_5_f0_0513(4516) - Fr02_beta7_5_f0_0513(3545);      % Input T = 32.43 s
w(4,1) = 2*pi./T(4,1);                                                 % Input w = 0.1938
temp1 = 3545;
temp2 = 4516;

Fr02.f(4).t = Fr02_beta7_5_f0_0513(temp1:temp2, 1);
Fr02.f(4).y = Fr02_beta7_5_f0_0513(temp1:temp2, 2)/1000;
Fr02.f(4).X = Fr02_beta7_5_f0_0513(temp1:temp2, 3)/Fnon;
Fr02.f(4).Y = Fr02_beta7_5_f0_0513(temp1:temp2, 4)/Fnon;
Fr02.f(4).N = Fr02_beta7_5_f0_0513(temp1:temp2, 8)/Mnon;

clear temp1 temp2

P = [sin(w(4,1)*Fr02.f(4).t), cos(w(4,1)*Fr02.f(4).t), ones(length(Fr02.f(4).t),1)];   % P = [sinwt, coswt, 5000*1 행렬]    총 0000 * 3 행렬
Q = Fr02.f(4).y;                                                                       % 0000*1 행렬 : y를 sin과 cos과 상수의 합으로 표현
temp = inv(P'*P)*P'*Q;                                                                 % P * temp = Q에서 temp를 구한거      총 3 * 1 행렬
Fr02.pha.y(4) = atan2(temp(2), temp(1));                                               % atan2(x,y) = atan(x/y)
Fr02.amp.y(4) = sqrt(temp(2)^2 + temp(1)^2);                                           % 진폭 구한거
clear P Q temp

Fr02.f(4).v  = + Fr02.amp.y(4) * cos(w(4,1)*Fr02.f(4).t + Fr02.pha.y(4))*w(4,1);
Fr02.f(4).vd = - Fr02.amp.y(4) * sin(w(4,1)*Fr02.f(4).t + Fr02.pha.y(4))*w(4,1)^2;
Fr02.f(4).v  = + Fr02.f(4).v /U;
Fr02.f(4).vd = + Fr02.f(4).vd/(U^2/L);

Fr02.amp_v(4)  = max(Fr02.f(4).v);
Fr02.amp_vd(4) = max(Fr02.f(4).vd);
clear  Fr02_beta7_5_f0_0513

%% f5
load Fr02_beta9_0_f0_0613
T(5,1) = Fr02_beta9_0_f0_0613(5115) - Fr02_beta9_0_f0_0613(4305);      % Input T = 32.43 s
w(5,1) = 2*pi./T(5,1);                                                 % Input w = 0.1938
temp1 = 4305;
temp2 = 5115;

Fr02.f(5).t = Fr02_beta9_0_f0_0613(temp1:temp2, 1);
Fr02.f(5).y = Fr02_beta9_0_f0_0613(temp1:temp2, 2)/1000;
Fr02.f(5).X = Fr02_beta9_0_f0_0613(temp1:temp2, 3)/Fnon;
Fr02.f(5).Y = Fr02_beta9_0_f0_0613(temp1:temp2, 4)/Fnon;
Fr02.f(5).N = Fr02_beta9_0_f0_0613(temp1:temp2, 8)/Mnon;

clear temp1 temp2

P = [sin(w(5,1)*Fr02.f(5).t), cos(w(5,1)*Fr02.f(5).t), ones(length(Fr02.f(5).t),1)];   % P = [sinwt, coswt, 5000*1 행렬]    총 0000 * 3 행렬
Q = Fr02.f(5).y;                                                                       % 0000*1 행렬 : y를 sin과 cos과 상수의 합으로 표현
temp = inv(P'*P)*P'*Q;                                                                 % P * temp = Q에서 temp를 구한거      총 3 * 1 행렬
Fr02.pha.y(5) = atan2(temp(2), temp(1));                                               % atan2(x,y) = atan(x/y)
Fr02.amp.y(5) = sqrt(temp(2)^2 + temp(1)^2);                                           % 진폭 구한거
clear P Q temp

Fr02.f(5).v  = + Fr02.amp.y(5) * cos(w(5,1)*Fr02.f(5).t + Fr02.pha.y(5))*w(5,1);
Fr02.f(5).vd = - Fr02.amp.y(5) * sin(w(5,1)*Fr02.f(5).t + Fr02.pha.y(5))*w(5,1)^2;
Fr02.f(5).v  = + Fr02.f(5).v /U;
Fr02.f(5).vd = + Fr02.f(5).vd/(U^2/L);

Fr02.amp_v(5)  = max(Fr02.f(5).v);
Fr02.amp_vd(5) = max(Fr02.f(5).vd);
clear  Fr02_beta9_0_f0_0613

%% f6
load Fr02_beta12_0_f0_0817
T(6,1) = Fr02_beta12_0_f0_0817(4730) - Fr02_beta12_0_f0_0817(4121);      % Input T = 32.43 s
w(6,1) = 2*pi./T(6,1);                                                 % Input w = 0.1938
temp1 = 4121;
temp2 = 4730;

Fr02.f(6).t = Fr02_beta12_0_f0_0817(temp1:temp2, 1);
Fr02.f(6).y = Fr02_beta12_0_f0_0817(temp1:temp2, 2)/1000;
Fr02.f(6).X = Fr02_beta12_0_f0_0817(temp1:temp2, 3)/Fnon;
Fr02.f(6).Y = Fr02_beta12_0_f0_0817(temp1:temp2, 4)/Fnon;
Fr02.f(6).N = Fr02_beta12_0_f0_0817(temp1:temp2, 8)/Mnon;

clear temp1 temp2

P = [sin(w(6,1)*Fr02.f(6).t), cos(w(6,1)*Fr02.f(6).t), ones(length(Fr02.f(6).t),1)];   % P = [sinwt, coswt, 5000*1 행렬]    총 0000 * 3 행렬
Q = Fr02.f(6).y;                                                                       % 0000*1 행렬 : y를 sin과 cos과 상수의 합으로 표현
temp = inv(P'*P)*P'*Q;                                                                 % P * temp = Q에서 temp를 구한거      총 3 * 1 행렬
Fr02.pha.y(6) = atan2(temp(2), temp(1));                                               % atan2(x,y) = atan(x/y)
Fr02.amp.y(6) = sqrt(temp(2)^2 + temp(1)^2);                                           % 진폭 구한거
clear P Q temp

Fr02.f(6).v  = + Fr02.amp.y(6) * cos(w(6,1)*Fr02.f(6).t + Fr02.pha.y(6))*w(6,1);
Fr02.f(6).vd = - Fr02.amp.y(6) * sin(w(6,1)*Fr02.f(6).t + Fr02.pha.y(6))*w(6,1)^2;
Fr02.f(6).v  = + Fr02.f(6).v /U;
Fr02.f(6).vd = + Fr02.f(6).vd/(U^2/L);

Fr02.amp_v(6)  = max(Fr02.f(6).v);
Fr02.amp_vd(6) = max(Fr02.f(6).vd);
clear  Fr02_beta12_0_f0_0817

%% f7
load Fr02_beta15_0_f0_1017
T(7,1) = Fr02_beta15_0_f0_1017(4761) - Fr02_beta15_0_f0_1017(4272);      % Input T = 32.43 s
w(7,1) = 2*pi./T(7,1);                                                 % Input w = 0.1938
temp1 = 4272;
temp2 = 4761;

Fr02.f(7).t = Fr02_beta15_0_f0_1017(temp1:temp2, 1);
Fr02.f(7).y = Fr02_beta15_0_f0_1017(temp1:temp2, 2)/1000;
Fr02.f(7).X = Fr02_beta15_0_f0_1017(temp1:temp2, 3)/Fnon;
Fr02.f(7).Y = Fr02_beta15_0_f0_1017(temp1:temp2, 4)/Fnon;
Fr02.f(7).N = Fr02_beta15_0_f0_1017(temp1:temp2, 8)/Mnon;

clear temp1 temp2

P = [sin(w(7,1)*Fr02.f(7).t), cos(w(7,1)*Fr02.f(7).t), ones(length(Fr02.f(7).t),1)];   % P = [sinwt, coswt, 5000*1 행렬]    총 0000 * 3 행렬
Q = Fr02.f(7).y;                                                                       % 0000*1 행렬 : y를 sin과 cos과 상수의 합으로 표현
temp = inv(P'*P)*P'*Q;                                                                 % P * temp = Q에서 temp를 구한거      총 3 * 1 행렬
Fr02.pha.y(7) = atan2(temp(2), temp(1));                                               % atan2(x,y) = atan(x/y)
Fr02.amp.y(7) = sqrt(temp(2)^2 + temp(1)^2);                                           % 진폭 구한거
clear P Q temp

Fr02.f(7).v  = + Fr02.amp.y(7) * cos(w(7,1)*Fr02.f(7).t + Fr02.pha.y(7))*w(7,1);
Fr02.f(7).vd = - Fr02.amp.y(7) * sin(w(7,1)*Fr02.f(7).t + Fr02.pha.y(7))*w(7,1)^2;
Fr02.f(7).v  = + Fr02.f(7).v /U;
Fr02.f(7).vd = + Fr02.f(7).vd/(U^2/L);

Fr02.amp_v(7)  = max(Fr02.f(7).v);
Fr02.amp_vd(7) = max(Fr02.f(7).vd);
clear  Fr02_beta15_0_f0_1017

%% 
for i =1:length(w)
    P = [ones(length(Fr02.f(i).v),1), Fr02.f(i).vd, Fr02.f(i).v, Fr02.f(i).v.^3];
    Q = [Fr02.f(i).Y, Fr02.f(i).N];
    temp = inv(P'*P)*P'*Q;
    Y0(i,1) = temp(1,1); Yvd(i,1) = temp(2,1); Yv(i,1) = temp(3,1); Yvvv(i,1) = temp(4,1);
    N0(i,1) = temp(1,2); Nvd(i,1) = temp(2,2); Nv(i,1) = temp(3,2); Nvvv(i,1) = temp(4,2);
    clear P Q temp
    
% X [1 v.^2]
    P = [ones(length(Fr02.f(i).v), 1), Fr02.f(i).v.^2];
    Q = [Fr02.f(i).X];
    temp = inv(P'*P)*P'*Q;
    X0(i,1) = temp(1,1); Xvv(i,1) = temp(2,1);
    clear P Q temp
end

%% Regression
% Velocity
A = [Fr02.amp_v'];
B = [Fr02.amp_v'].^2;
C = [Fr02.amp_v'].^3;

Vel.X = Xvv.*B;
Vel.Y = Yv.*A + Yvvv.*C;
Vel.N = Nv.*A + Nvvv.*C;

Q = [Vel.X];
P = [B];
R = inv(P'*P)*P'*Q;
D.Xvv = R(1,1);
clear Q P R

Q = [Vel.Y, Vel.N];
P = [A, C];
R = inv(P'*P)*P'*Q;
D.Yv = R(1,1); D.Yvvv(1) = R(2,1);
D.Nv = R(1,2); D.Nvvv(1) = R(2,2);
clear Q P R

r = (0:0.01:0.26)';

Vel.Y1 = D.Yv.*r + D.Yvvv.*r.^3;
Vel.N1 = D.Nv.*r + D.Nvvv.*r.^3;

% Acc
E = [Fr02.amp_vd'];

Acc.Y = Yvd.*E;
Acc.N = Nvd.*E;

Q = [Acc.Y, Acc.N];
P = [E];
R = inv(P'*P)*P'*Q;
D.Yvd = R(1);
D.Nvd = R(2);
clear Q P R

rd = (0:0.01:1)';

Acc.Y1 = D.Yvd.*rd;
Acc.N1 = D.Nvd.*rd;

%% plot
figure(1)
subplot(121); grid on; hold on;
plot(A, Vel.Y,'bo');
plot(r, Vel.Y1, '--r');
xlabel('v');
ylabel('Y');
title('Yv');

subplot(122); grid on; hold on;
plot(A, Vel.N, 'bo');
plot(r, Vel.N1, '--r');
xlabel('v');
ylabel('N');
title('Nv');

figure(2)
subplot(121); grid on; hold on;
plot(E, Acc.Y, 'bo');
plot(rd, Acc.Y1, '--r');
xlabel('vdot');
ylabel('Y');
title('Yvd');

subplot(122); grid on; hold on;
plot(E, Acc.N, 'bo');
plot(rd, Acc.N1, '--r');
xlabel('vdot');
ylabel('N');
title('Nvd');

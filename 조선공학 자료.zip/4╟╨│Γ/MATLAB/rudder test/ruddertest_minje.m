clc
clear all
close all

L = 3.147; % 배의길이다(m)
T = 0.112; % 배의 흘수다(m)
Fr = [0.1,0.2]; % 배의 프루드수다
U = Fr*sqrt(9.81*L); % 유체의 속도다
rho = 997.671;

Fnon = 1/2*rho*L*T*U.^2; % 힘의 무차원
Mnon = 1/2*rho*L.^2*T*U.^2; % 모멘트의 무차원

load rudder_test_data
Fr01_X = data(1:15,1)/Fnon(1);
Fr02_X = data(18:32,1)/Fnon(2);

Fr01_Y = data(1:15,2)/Fnon(1);
Fr02_Y = data(18:32,2)/Fnon(2);

Fr01_N = data(1:15,6)/Mnon(1);
Fr02_N = data(18:32,6)/Mnon(2);

D2R = pi/180;
R2D = 180/pi;
delta = (35:-5:-35)'*D2R;

%1. X-Force
P = Fr01_X; %타각에 따른 힘
Q = [ones(15,1),delta.^2]; %[1,delta^2] 15*2 행렬
R = inv(Q'*Q)*Q'*P;
Fr01_X0 = R(1,1); Fr01_Xdd = R(2,1);

P = Fr02_X;
Q = [ones(15,1),delta.^2];
R = inv(Q'*Q)*Q'*P;
Fr02_X0 = R(1,1); Fr02_Xdd = R(2,1);

%2. Y-Force, N-Force
P = [Fr01_Y, Fr01_N]; %타각에 따른 힘
Q = [ones(15,1), delta, delta.^3]; %[1,delta^2] 15*2 행렬
R = inv(Q'*Q)*Q'*P;
Fr01_Y0 = R(1,1); Fr01_Yd = R(2,1); Fr01_Yddd = R(3,1);
Fr01_N0 = R(1,2); Fr01_Nd = R(2,2); Fr01_Nddd = R(3,2);

P = [Fr02_Y, Fr02_N];
Q = [ones(15,1), delta, delta.^3];
R = inv(Q'*Q)*Q'*P;
Fr02_Y0 = R(1,1); Fr02_Yd = R(2,1); Fr02_Yddd = R(3,1);
Fr02_N0 = R(1,2); Fr02_Nd = R(2,2); Fr02_Nddd = R(3,2);

delta = (+35:-0.1:-35)'*D2R;

Fr01_X_fitting = Fr01_X0 + Fr01_Xdd*delta.^2;
Fr02_X_fitting = Fr02_X0 + Fr02_Xdd*delta.^2;

Fr01_Y_fitting = Fr01_Y0 + Fr01_Yd*delta + Fr01_Yddd*delta.^3;
Fr02_Y_fitting = Fr02_Y0 + Fr02_Yd*delta + Fr02_Yddd*delta.^3;

Fr01_N_fitting = Fr01_N0 + Fr01_Nd*delta + Fr01_Nddd*delta.^3;
Fr02_N_fitting = Fr02_N0 + Fr02_Nd*delta + Fr02_Nddd*delta.^3;

d = delta.*R2D;

%% plot
load rudder_test_data

figure(1); hold on; grid on;
plot(35:-5:-35, data(1:15,1)/Fnon(1), 'bo');
plot(35:-5:-35, data(18:32,1)/Fnon(2), 'ro');
plot(d, Fr01_X_fitting, '--b');
plot(d, Fr02_X_fitting, '--r');
title('rudder test X');
legend('Fr 0.1', 'Fr 0.2', 'fitting(Fr 0.1)', 'fitting(Fr 0.2)');
xlabel('degree');
ylabel('X-Force');
axis([-40 40 -0.1 0.05]);

figure(2); hold on; grid on;
plot(35:-5:-35, data(1:15,2)/Fnon(1), 'bo');
plot(35:-5:-35, data(18:32,2)/Fnon(2), 'ro');
plot(d, Fr01_Y_fitting, '--b');
plot(d, Fr02_Y_fitting, '--r');
title('rudder test Y');
legend('Fr 0.1', 'Fr 0.2', 'fitting(Fr 0.1)', 'fitting(Fr 0.2)');
xlabel('degree');
ylabel('Y-Force');


figure(3); hold on; grid on;
plot(35:-5:-35, data(1:15,6)/Mnon(1), 'bo');
plot(35:-5:-35, data(18:32,6)/Mnon(2), 'ro');
plot(d, Fr01_N_fitting, '--b');
plot(d, Fr02_N_fitting, '--r');
title('rudder test N');
legend('Fr 0.1', 'Fr 0.2', 'fitting(Fr 0.1)', 'fitting(Fr 0.2)');
xlabel('degree');
ylabel('N-Force');


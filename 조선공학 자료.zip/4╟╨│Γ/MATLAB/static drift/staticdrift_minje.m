clc
clear
close all

load static_test_data % 사항시험 데이터 불러왔다.
L = 3.147; % 배의길이다
T = 0.112; % 배의 흘수다
Fr = [0.1,0.2]; % 배의 프루드수다
U = Fr*sqrt(9.81*L); % 배의 속도다
rho = 997.671;

Fnon = 1/2*rho*L*T*U.^2;
Mnon = 1/2*rho*L^2*T*U.^2;

Fr_01_X = data(1:15, 1)/Fnon(1);
Fr_02_X = data(18:32, 1)/Fnon(2);
Fr_01_Y = data(1:15, 2)/Fnon(1);
Fr_02_Y = data(18:32, 2)/Fnon(2);
Fr_01_N = data(1:15, 6)/Mnon(1);
Fr_02_N = data(18:32, 6)/Mnon(2);

b = [-15, -12, -9, -7.5, -6, -4.5, -3, 0, 3, 4.5, 6, 7.5, 9, 12, 15]';
D2R = pi/180;
v = -sin(b*D2R);

%% 0.1
C = Fr_01_X; 
A = [ones(15,1),v.^2]; 
B = inv(A'*A)*A'*C;
Fr_01_X0 = B(1,1); Fr_01_Xvv = B(2,1);

C = [Fr_01_Y, Fr_01_N];
A = [ones(15,1),v,v.^3];
B = inv(A'*A)*A'*C;
Fr_01_Y0 = B(1,1); Fr_01_Yv=B(2,1); Fr_01_Yvvv=B(3,1);
Fr_01_N0 = B(1,2); Fr_01_Nv=B(2,2); Fr_01_Nvvv=B(3,2);

b_1 = [-15:0.1:15]';
v_1 = -sin(b_1*D2R);
Fr_01_X_fitting = Fr_01_X0 + Fr_01_Xvv*v_1.^2;
Fr_01_Y_fitting = Fr_01_Y0 + Fr_01_Yv*v_1 + Fr_01_Yvvv*v_1.^3;
Fr_01_N_fitting = Fr_01_N0 + Fr_01_Nv*v_1 + Fr_01_Nvvv*v_1.^3;

%% 0.2
C = Fr_02_X; 
A = [ones(15,1),v.^2]; 
B = inv(A'*A)*A'*C;
Fr_02_X0 = B(1,1); Fr_02_Xvv = B(2,1);

C = [Fr_02_Y, Fr_02_N];
A = [ones(15,1),v,v.^3];
B = inv(A'*A)*A'*C;
Fr_02_Y0 = B(1,1); Fr_02_Yv=B(2,1); Fr_02_Yvvv=B(3,1);
Fr_02_N0 = B(1,2); Fr_02_Nv=B(2,2); Fr_02_Nvvv=B(3,2);

b_2 = [-15:0.1:15]';
v_2 = -sin(b_2*D2R);
Fr_02_X_fitting = Fr_02_X0 + Fr_02_Xvv*v_2.^2;
Fr_02_Y_fitting = Fr_02_Y0 + Fr_02_Yv*v_2 + Fr_02_Yvvv*v_2.^3;
Fr_02_N_fitting = Fr_02_N0 + Fr_02_Nv*v_2 + Fr_02_Nvvv*v_2.^3;


%% plot
figure(1); hold on; grid on;
plot(b, Fr_01_X, 'o');
plot(b_1, Fr_01_X_fitting);
plot(b, Fr_02_X, 'o');
plot(b_2, Fr_02_X_fitting);
legend('실험', '피팅')

figure(2); hold on; grid on;
plot(b, Fr_01_Y, 'o');
plot(b_1, Fr_01_Y_fitting);
plot(b, Fr_02_Y, 'o');
plot(b_2, Fr_02_Y_fitting);
legend('실험', '피팅');

figure(3); hold on; grid on;
plot(b, Fr_01_N, 'o');
plot(b_1, Fr_01_N_fitting);
plot(b, Fr_02_N, 'o');
plot(b_2, Fr_02_N_fitting);
legend('실험', '피팅');

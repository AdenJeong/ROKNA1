'''9.17.(금) 프로그래밍 과제
내용 : 파이선 외부라이브러리의 설치와 활용
제출일 : 9.19.(일) 2400시 까지
제출방법 : 해종체 메일이용, 소스코드와 그래프(.png 파일 형식) 압축 제출
1. 다음 리스트를 lst1을 생성하시오
조건 1 ) 원소의 수는 총 100개임
조건 2 ) 각 원소는 0부터 10 사이의 임의 실수임
2. lst1을 이용하여 도표(그래프)를 그리시오
조건 1 ) x축의 범위는 [0, 100], y 축의 범위는 [0, 10] 임.
조건 2) lst1의 각 원소값을 꺽은선 그래프로 그리시오.
조건 3) 그래프의 색상은 자유롭게 정하시오
조건 4) x축의 축이름(label)는 "Step" , y축의 축이름(label)은 "Signal" 임.
조건 5) 도표의 제목은 "Random Noise" 임.
조건 6) 도표에 격자(grid)를 추가하시오.
조건 7) plot.png로 도표를 저장하세요
3. 기타 표의 형태는 첨부한 그림을 참고하세요
4. 문제 해결을 위한 구글 검색 키워드는 (pip, matplotlib) 입니다.
8115616_정연수_객체지향프로그래밍'''

import matplotlib.pyplot as plt
import numpy as np

lst1 = [10*np.random.rand() for i in range(100)]

plt.title('Random Noise')
plt.plot(lst1, color = 'green')
plt.xlim(0,100)
plt.ylim(0,10)
plt.xlabel('Step')
plt.ylabel('Signal')
plt.grid()
plt.savefig('plot.png', format="png", dpi=300)
plt.show()

import sys
from PyQt5.QtGui import *
from PyQt5.QtCore import *

import ctypes
import ctypes.wintypes

user32 =  ctypes.windll.user32
HUD_WIDTH = 100
HUD_HEIGHT = 50 
WINDOW_NAME = "Window name" #Replace this by the name of an opened window 

class Hud(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.hwnd = self.winId().__int__()


    def initUI(self):
        self.setWindowFlags(Qt.FramelessWindowHint)   
        self.resize(HUD_WIDTH,HUD_HEIGHT)   
        self.textArea = QLabel()
        self.setCentralWidget(self.textArea);  
        self.setStyleSheet("background-color: rgb(0, 0, 0);color: rgb(255,255,255);")
        self.textArea.setText("Hello")
        self.textArea.setAlignment(Qt.AlignCenter)
        self.show()


class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow,self).__init__()
        self.initUI()
    def initUI(self):
        self.launch_hud_button = QPushButton("Launch HUD",self)
        self.launch_hud_button.clicked.connect(self.launchHud)
        self.show()
    def launchHud(self):
        window_handle = user32.FindWindowW(0,WINDOW_NAME)
        if window_handle != 0 :
            self.hud = Hud()
            user32.SetParent(self.hud.hwnd,window_handle)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_window = MainWindow()
    sys.exit(app.exec_())  

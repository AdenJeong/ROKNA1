
import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from threading import Timer
import time
 
QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
 
class CWidget(QWidget):
 
    def __init__(self):
 
        super().__init__()
        self.year = QLCDNumber(self)        
        self.month = QLCDNumber(self)
        self.day = QLCDNumber(self)
        self.hour = QLCDNumber(self)
        self.min = QLCDNumber(self)
        self.sec = QLCDNumber(self)
 
        ## LCD 글자색 변경
        #pal = QPalette()        
        #pal.setColor(QPalette.WindowText, QColor(255,0,0))
        #self.sec.setPalette(pal)     
         
        ## LCD 배경색 변경
        #pal = QPalette()        
        #pal.setColor(QPalette.Background, QColor(255,0,0))
        #self.min.setPalette(pal)  
        #self.min.setAutoFillBackground(True)
 
        self.initUI()
 
 
    def initUI(self):        
         
        hbox1 = QHBoxLayout()
        hbox1.addWidget(self.year)
        hbox1.addWidget(self.month)
        hbox1.addWidget(self.day)
 
        hbox2 = QHBoxLayout()
        hbox2.addWidget(self.hour)
        hbox2.addWidget(self.min)
        hbox2.addWidget(self.sec)
 
        vbox = QVBoxLayout()
        vbox.addLayout(hbox1)
        vbox.addLayout(hbox2)
 
        self.setLayout(vbox)
 
        self.setWindowTitle('시계')
        self.setGeometry(200,200, 400, 200)  
 
        self.showtime()
 
    def showtime(self):
        # 1970년 1월 1일 0시 0분 0초 부터 현재까지 경과시간 (초단위)
        t = time.time()
        # 한국 시간 얻기
        kor = time.localtime(t)
        # LCD 표시
        self.year.display(kor.tm_year)
        self.month.display(kor.tm_mon)
        self.day.display(kor.tm_mday)
        self.hour.display(kor.tm_hour)
        self.min.display(kor.tm_min)
        self.sec.display(kor.tm_sec)
 
        # 타이머 설정  (1초마다, 콜백함수)
        timer = Timer(1, self.showtime)
        timer.start()
 
 
if __name__ == '__main__':
     
    app = QApplication(sys.argv)
    w = CWidget()
    w.show()    
    sys.exit(app.exec_())

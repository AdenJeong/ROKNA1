from tkinter import*
from random import *
from time import sleep
import numpy as np

window = Tk()

canvas = Canvas(window, width = 500, height = 500)
canvas.pack()


'''canvas.create_line(250,250,200,100, 100, 50, 10, 10, fill = "blue",
                   width = 2, smooth = True)'''

a = 0
b = 0
deg = 90
loopnum = True
while loopnum:

    canvas.create_line(150,150,150+100*b,150+100*a, fill = "red", width = 2)

#    pygame.draw.line(srf, (0,0,0), (150, 150), (150+100*b,150+100*a), 2)
#    pygame.draw.line(srf, (0,0,0), (150, 150), (150-100*b,150-100*a), 2)

    #(윈도우창,선 색깔, 원점위치, 끝점위치,  선의 두께)
    
    a = np.cos(deg*np.pi/180)
    b = np.sin(deg*np.pi/180)

    deg = deg + randint(-10,10)
    

    print(deg)

    window.update()
    sleep(0.1)

#    pygame.time.delay(200)
#    pygame.display.flip()


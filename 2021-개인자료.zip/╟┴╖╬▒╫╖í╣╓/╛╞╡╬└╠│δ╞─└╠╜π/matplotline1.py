import matplotlib.pyplot as plt
from random import *
import numpy as np

a=0
b=0
deg=0
for i in range(15):
    deg = deg + randint(-5, 10)
    a = np.sin(deg * np.pi / 180)     # sin값, deg 값을 라디안값으로 변경해줌
    b = np.cos(deg * np.pi / 180)

    plt.plot([150, 150, 150 - 100 * b, 150 + 100 * a])
    plt.show()

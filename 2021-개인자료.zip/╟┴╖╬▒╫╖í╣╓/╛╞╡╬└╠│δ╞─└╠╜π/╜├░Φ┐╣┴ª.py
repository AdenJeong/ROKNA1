import sys
import math
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

from threading import Thread
import time

QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)

class CWidget(QWidget):

    displayUpdate = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.diameter = 0
        self.radius = 0
        self.cpt = QPointF()
        self.wrect = QRectF()
        self.bOnline = False
        self.text = 'Ocean Coding School'
        self.utc = 9 #Seoul, Korea

        self.displayUpdate.connect(self.update)

        self.thread = Thread(target=self.threadFunc)
        self.bExit = False
        self.thread.start()
        self.initUI()

    def initUI(self):
        vbox = QVBoxLayout()        
        #UTC time
        self.cmb = QComboBox(self)
        for i in range(-12, 15, 1):
            self.cmb.addItem('UTC {}'.format(i))
        self.cmb.setCurrentIndex(21)
        self.cmb.currentIndexChanged[int].connect(self.onChangedUTC)
        vbox.addWidget(self.cmb)

        #draw option
        text = ['Bezel', 'Index', 'Date', 'Hands']
        self.chk = []
        for i in range(len(text)):
            chk = QCheckBox(text[i], self)
            chk.setChecked(True)
            self.chk.append(chk)
            vbox.addWidget(chk)
        vbox.addStretch(1)

        #Clock frame
        self.frame = QFrame(self)
        self.frame.setFrameStyle(QFrame.Panel);
        
        hbox = QHBoxLayout()                
        hbox.addLayout(vbox)                
        hbox.addWidget(self.frame, 1)
        
        self.setLayout(hbox)
        self.setGeometry(100,100,500,400)
        self.setWindowTitle(self.text)
        self.show()

    def onChangedUTC(self, i):
        self.utc = i-12

    def getRotatedPos(self, deg, radius, cpt):        
        rad = deg * math.pi / 180
        dx = math.sin(rad)*radius
        dy = math.cos(rad)*radius       
        return QPointF(cpt.x()+dx, cpt.y()-dy)

    def paintEvent(self, e):        
        qp = QPainter()
        qp.begin(self)
        qp.setRenderHint(QPainter.Antialiasing)
        self.bOnline = NTP.getNTPtime(utc_std = self.utc)
        if self.chk[0].isChecked():
            self.drawBezel(qp)
        if self.chk[1].isChecked():
            self.drawIndex(qp)
        if self.chk[2].isChecked():
            self.drawDate(qp)
        if self.chk[3].isChecked():
            self.drawClockHands(qp)        
        qp.end()

    def resizeEvent(self, e):
        self.resizeClock()
        
    def closeEvent(self, e):
        self.bExit = True

    def resizeClock(self):        
        # clock resize        
        w = self.frame.rect().width()
        h = self.frame.rect().height()        
        self.diameter = h if w>h else w  
        self.diameter -= 10
        
        self.radius = self.diameter/2
        self.cpt = self.frame.mapToParent(self.frame.rect().center())
        
        self.wrect = QRectF(self.cpt.x()-self.radius, self.cpt.y()-self.radius, self.diameter, self.diameter)

        # logo resize
        size = self.radius                 
        self.logoRect = QRectF(self.cpt, QSizeF(size, size/2))
        self.logoRect.adjust(-size/2, 0, -size/2, 0)

        # date resize
        size = self.radius / 3                 
        self.dateRect = QRectF(self.cpt, QSizeF(size, size/3))
        self.dateRect.adjust(-size*2, 0, -size*2, 0)

        # font resize (Big, Small)
        fname = 'Arial'
        self.fontB = QFont(fname, self.radius/8)        
        self.fontS = QFont(fname, self.radius/25)

    def drawBezel(self, qp):
        qp.drawEllipse(self.wrect)

    def drawIndex(self, qp):
        # logo        
        qp.setFont(self.fontS)
        if self.bOnline:
            conn = 'On-line'
        else:
            conn = 'Off-line'
            
        td = str(NTP.time.utcoffset())        
        utc = 'UTC {}'.format(td)
        qp.drawText(self.logoRect, Qt.AlignCenter, self.text+'\n'+utc+'\n'+conn)
        
        # time mark
        bold = 0  
        hour = 1
        for i in range(30, 390, 6):

            pt1 = self.getRotatedPos(i, self.radius, self.cpt)
            pt2 = self.getRotatedPos(i, -self.radius/10, pt1)

            if bold%5 == 0:                
                qp.setPen(QPen(Qt.black, self.radius/50, Qt.SolidLine, Qt.FlatCap))

                size = self.radius / 8
                pt3 = self.getRotatedPos(i, -self.radius/15, pt2)
                pt3-=QPointF(size, size)
                rect = QRectF(pt3, QSizeF(size*2, size*2))
                
                qp.setFont(self.fontB)
                qp.drawText(rect,  Qt.AlignCenter, str(hour))
                hour+=1;
            else:
                qp.setPen(Qt.black)
            
            qp.drawLine(pt1, pt2)    
            bold+=1

    def drawDate(self, qp):        
        date = NTP.time.strftime('%Y.%m.%d %p')
        size = self.dateRect.height()/4
        qp.drawRoundedRect(self.dateRect, size, size)
        qp.setFont(self.fontS)        
        qp.drawText(self.dateRect, Qt.AlignCenter, date)        

    def drawClockHands(self, qp):        
        sec = NTP.time.second
        min = NTP.time.minute
        hour = NTP.time.hour
        # hand of second
        secdeg = sec*6
        secpt = self.getRotatedPos(secdeg, self.radius*0.9, self.cpt)        
        qp.setPen(QPen(Qt.black, 1, Qt.SolidLine, Qt.RoundCap))
        qp.drawLine(self.cpt, secpt)

        # hand of minute
        mindeg = (min+sec/60)*6
        minpt = self.getRotatedPos(mindeg, self.radius*0.8, self.cpt)
        pensize = self.radius/50        
        qp.setPen(QPen(Qt.black, pensize, Qt.SolidLine, Qt.RoundCap))
        qp.drawLine(self.cpt, minpt)

        # hand of hour
        hourdeg = ((hour % 12) + (min / 60.0))*30
        hourpt = self.getRotatedPos(hourdeg, self.radius*0.7, self.cpt)
        pensize = self.radius/30        
        qp.setPen(QPen(Qt.black, pensize, Qt.SolidLine, Qt.RoundCap))
        qp.drawLine(self.cpt, hourpt)

    def threadFunc(self):
        while not self.bExit:
            self.displayUpdate.emit()
            time.sleep(0.1)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    w = CWidget()
    sys.exit(app.exec_())

import pygame
from pygame.locals import *
import numpy as np



pygame.init()

srf = pygame.display.set_mode((300,300))



srf.fill((255,255,255))

pygame.draw.line(srf, (100,100,100), (150, 20), (200, 20), 2)
#(윈도우창, 선의 두께

pygame.time.delay(40)
pygame.display.flip()

from tkinter import*
from random import *
from time import sleep
import numpy as np
import serial

ard = serial.Serial('COM4',115200)

window = Tk()

canvas = Canvas(window, width = 300, height = 300)
canvas.pack()


'''canvas.create_line(250,250,200,100, 100, 50, 10, 10, fill = "blue",
                   width = 2, smooth = True)'''



a = 0
b = 0
deg = 0
loopnum = True
while loopnum:
    odd = ard.readline()
    deg = float(odd.decode()[:len(odd)-1])
    a = np.sin(deg*np.pi/180)
    b = np.cos(deg*np.pi/180)
    canvas.create_line(150,150,150-100*b,150+100*a, fill = "red", width = 2)
    canvas.create_line(150,150,150+100*b,150-100*a, fill = "red", width = 2)
    canvas.create_oval(40,40, 260,260)
    print(deg)
    deg = deg + randint(-5,10)
    canvas.update()
    canvas.delete(ALL)

    sleep(0.1)
    

import pygame
from pygame.locals import *
from random import *
import numpy as np



pygame.init()

srf = pygame.display.set_mode((300,300))


a = 0
b = 0
deg = 90
loopnum = True
while loopnum:
    
    srf.fill((255,255,255))

    pygame.draw.line(srf, (0,0,0), (150, 150), (150+100*b,150+100*a), 2)
    pygame.draw.line(srf, (0,0,0), (150, 150), (150-100*b,150-100*a), 2)

    #(윈도우창,선 색깔, 원점위치, 끝점위치,  선의 두께)
    
    a = np.cos(deg*np.pi/180)
    b = np.sin(deg*np.pi/180)

    deg = deg + randint(-10,10)
    

    print(deg)

    pygame.time.delay(200)
    pygame.display.flip()


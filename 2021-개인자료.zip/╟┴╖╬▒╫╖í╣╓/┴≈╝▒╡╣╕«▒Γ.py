from tkinter import*
from random import *
from time import sleep
import numpy as np

window = Tk()

canvas = Canvas(window, width = 500, height = 500)
canvas.pack()


'''canvas.create_line(250,250,200,100, 100, 50, 10, 10, fill = "blue",
                   width = 2, smooth = True)'''

canvas.create_line(150,150,200,150, fill = "red", width = 2)

a = 0
b = 0
deg = 90
loopnum = True
while loopnum:

    a = np.cos(deg*np.pi/180)
    b = np.sin(deg*np.pi/180)

    deg = deg + randint(-10,10)

    canvas.move(1,0,b)
    canvas.u
    print(deg)

    window.update()
    sleep(0.05)

import serial
from matplotlib import pyplot as plt

ard = serial.Serial('COM3',9600,)
x_values = []
y_values = []
xnum = 0
print("insert op :", end=' ')
op = input()
ard.write(op.encode())
while True:

    xnum = xnum+1
    odd = ard.readline()
    num = int(odd.decode()[:len(odd)-1])
    x_values.insert(xnum,xnum)
    y_values.insert(num,num)
    print(num)
    if num > 10000:
        break
plt.plot(x_values, y_values, label='num')
plt.legend()
plt.show()
'''9.3.(금) 프로그래밍 과제
1. 아래 문제를 해결하는 프로그램을 작성하고, 소스코드를 해종체 메일로 제출하세요.
    * 단 제출시 *.py 확장자로 제출하세요.
2. 문제
     중대의 평균 성적을 계산하는 프로그램을 작성하고자 한다.
     조건.1 중대원의 성적은 data.csv 파일로 저장되어 있다.(아래 첨부 파일 참조)
     조건.2 중대원의 수는 각 중대마다 다르다.
     조건.3 성적의 평균을 계산하여 result.txt 파일로 저장한다.
     조건.4 result.txt 파일에는 "평균 성적 : 00.00점" 형태로 평균성적이 저장되어야 한다.
3. 오늘 1200시 이전까지 해종체(메일)로 제출바랍니다.
    * 해종체 오류로 접속이 불가능한 경우에 한하여 메신저로 제출바랍니다.
4. 예상 풀이 시간은 15분입니다.

8115616 정연수 객체지향프로그래밍 평소시험 1 답안제출
'''

f = open('data.csv', 'r')
result = open('result.txt', 'w')
avgscore = 0
data = f.readlines()

for i in range(len(data)):
    a = data[i].split(',')
    avgscore = avgscore + int(a[1].rstrip())
avgscore = "평균 성적 : %0.2f점" %(avgscore / len(data))

result.write(avgscore)

f.close()
result.close()

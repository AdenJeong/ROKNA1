import serial

ser = serial.Serial('com3',57600)

count = 0
word = ''
while True:
    print("insert op :", end=' ')
    op = input()
    ser.write(op.encode())
    while True:

        line = ser.readline()
        line = line.decode()[:len(line)-2]
        word += line
        count += 1
        if count == len(op):
            count = 0
            break
    print(op)
    print(word)

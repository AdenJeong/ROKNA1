from matplotlib import pyplot as plt

class tempdata:
    def __init__(self):  # 클래스를 시작하면서 실행하는 코드들.
        f = open("temp.txt", 'r') # 읽어올 파일을 열기
        self.xy_values = {}       # 딕셔너리를 사용해 xy 값을 저장해보기
        self.x_values = []  # x축 지점의 값들
        self.y_values = []  # y축 지점의 값들
        temp = f.readline()  # 온도 읽기?
        num = 2000          # 2000년도가 시작년도
        while True:
            line = f.readline()
            if not line:
                break
            self.xy_values[num]=float(line)
            self.x_values.insert(num, num)
            self.y_values.insert(num, float(line))
            num = num + 1
        f.close()

    def maxtemp(self):
        valuelist = list(self.xy_values.values())
        self.maxnum = [k for k, v in self.xy_values.items() if v == max(valuelist)]
        self.maxnumval = []
        for i in range(len(self.maxnum)):
            self.maxnumval.insert(i, a.xy_values[self.maxnum[i]])
        return self.maxnum

    def mintemp(self):
        return min(self.y_values)

a = tempdata()
a.maxtemp()

plt.scatter(a.maxnum, a.maxnumval, s = 20, c = 'r',label = 'max %f'%a.maxnumval[0] )
plt.plot(a.x_values, a.y_values,label = 'Busan')	# line 그래프를 그립니다
plt.axhline(y = a.maxnumval[0], c = 'b', label = 'max %f'%a.maxnumval[0])  # y = 2에 파란색 수평선 긋기
plt.axis([1999, 2020, 18, 20])
plt.grid()
plt.xlabel('Year')
plt.ylabel('Temp')
plt.title('average temp of Busan')
plt.legend()
plt.show()	# 그래프를 화면에 보여줍니다
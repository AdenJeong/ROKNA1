import serial

ser = serial.Serial('com3',9600)
while True:
    print("insert op :", end=' ')
    op = input()
    ser.write(op.encode())